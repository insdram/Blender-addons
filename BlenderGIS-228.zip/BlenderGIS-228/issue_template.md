<!--
Please respect the issue template describe here :
https://github.com/domlysz/BlenderGIS/issues/289

Issues that does not respect the template will be automatically closed.

**Mac users warning :** currently the addon does not work on Mac with Blender 2.80 to 2.82. Please do not report the issue here. It's already solved with Blender 2.83.
 -->

# **Blender and OS versions**

<!-- Tag here which version of Blender you are using and what's your operating system.-->

# **Describe the bug**

<!-- A clear and concise description of what the bug is. -->

# **How to Reproduce**

<!-- Steps, to reproduce the behavior. Screencasts or screenshots welcome -->

# **Error message**

<!--If the addon crash, report here the complete error message reported in the logs-->
