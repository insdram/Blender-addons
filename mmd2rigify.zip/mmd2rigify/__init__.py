
'''
Copyright (C) 2021

Created by yhf and ...

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''
bl_info = {
    "name": "mmd2rigify",
    "author": "yhf ...我倒是没遇到问题",
    "blender": (3, 0, 0),
    "location": "",
    "description": "Apply MMD motion to human_meta_rig",
    "doc_url": "https://www.bilibili.com",
    "category": "导入_vmd",
    }
import sys, os
file_dir = os.path.join(os.path.dirname(__file__), 'MMD_use')
if file_dir not in sys.path:
    sys.path.append(file_dir)
import bpy
import mmd_tools_change
class Mmd2rigify_panel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "MMD 到 Rigfy"
    bl_idname = "SCENE_PT_layout"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"
    bl_order = 1
    bl_options = {'HEADER_LAYOUT_EXPAND'}
    def draw(self, context):
        layout = self.layout
        row = layout.row()
        sub = row.row(align=True)
        sub.operator('mmd_to_rigfy.import_vmd', text='导入.vmd')
        sub = row.row(align=True)
        sub.operator('mmd_to_rigfy.export_vmd', text='导出.vmd')
        sub = row.row(align=True)
        sub.operator('mmd_to_rigfy.simple_chain', text='链条')
        row = layout.row()
        row.label(text="脖子和腿建议直一些，挺胸!抬头!脚骨长于脚等等")
def register():
    mmd_tools_change.register()
    bpy.utils.register_class(Mmd2rigify_panel)
def unregister():
    mmd_tools_change.unregister()
    bpy.utils.unregister_class(Mmd2rigify_panel)
if __name__ == "__main__":
    register()
