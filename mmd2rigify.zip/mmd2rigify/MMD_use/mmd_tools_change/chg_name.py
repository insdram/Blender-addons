# -*- coding: utf-8 -*-

import logging
import bpy
from mmd_tools_change.core import vmd

rig_to_vmd_tuples=[
    ('head','Head'),
    ('neck','Neck'),
    ('teeth.T',"Upper齿"),
    ('teeth.B',"Lower齿"),
    ('shoulder.L','ShoulderP_L'),
    ('shoulder.R','ShoulderP_R'),
    ('upper_arm_fk.L','Arm_L'),
    ('upper_arm_fk.R','Arm_R'),
    ('forearm_fk.L','Elbow_L'),
    ('forearm_fk.R','Elbow_R'),
    ('hand_fk.L','Wrist_L'),
    ('hand_fk.R','Wrist_R'),
    ('shin_fk.L','Knee_L'),
    ('shin_fk.R','Knee_R'),
    ("foot_ik.L",'LegIK_L'),
    ("foot_ik.R",'LegIK_R'),
    ("MCH-foot_roll.L","Ankle_L"),
    ("MCH-foot_roll.R","Ankle_R"),
    ("MCH-foot_ik.parent.R","LegIKParent_R"),
    ("MCH-foot_ik.parent.L","LegIKParent_L"),
    ("foot_spin_ik.L",'ToeTipIK_L'),
    ("foot_spin_ik.R",'ToeTipIK_R'),
    ('toe_ik.L','LegTipEX_L'),
    ('toe_ik.R','LegTipEX_R'),
    ('foot_fk.L','Ankle_L'),
    ('foot_fk.R','Ankle_R'),
    ("spine_fk.003",'UpperBody2'),
    ("spine_fk.002",'UpperBody'),
    ('spine_fk','LowerBody'),
    ('MCH-torso.parent','Center'),
    ('torso','Groove'),
    ('thumb.01.L','Thumb0_L'),
    ('thumb.01.R','Thumb0_R'),
    ('thumb.02.L','Thumb1_L'),
    ('thumb.02.R','Thumb1_R'),
    ('thumb.03.L','Thumb2_L'),
    ('thumb.03.R','Thumb2_R'),
    ('f_index.01.L','IndexFinger1_L'),
    ('f_index.01.R','IndexFinger1_R'),
    ('f_index.02.L','IndexFinger2_L'),
    ('f_index.02.R','IndexFinger2_R'),
    ('f_index.03.L','IndexFinger3_L'),
    ('f_index.03.R','IndexFinger3_R'),
    ('f_middle.01.L','MiddleFinger1_L'),
    ('f_middle.01.R','MiddleFinger1_R'),
    ('f_middle.02.L','MiddleFinger2_L'),
    ('f_middle.02.R','MiddleFinger2_R'),
    ('f_middle.03.L','MiddleFinger3_L'),
    ('f_middle.03.R','MiddleFinger3_R'),
    ('f_ring.01.L','RingFinger1_L'),
    ('f_ring.01.R','RingFinger1_R'),
    ('f_ring.02.L','RingFinger2_L'),
    ('f_ring.02.R','RingFinger2_R'),
    ('f_ring.03.L','RingFinger3_L'),
    ('f_ring.03.R','RingFinger3_R'),
    ('f_pinky.01.L','LittleFinger1_L'),
    ('f_pinky.01.R','LittleFinger1_R'),
    ('f_pinky.02.L','LittleFinger2_L'),
    ('f_pinky.02.R','LittleFinger2_R'),
    ('f_pinky.03.L','LittleFinger3_L'),
    ('f_pinky.03.R','LittleFinger3_R'),
    ('root','ParentNode'),
]

def chg_name(CC,filepath):
    CCpB=CC.pose.bones
    Arm_name = CC.name
    bpy.ops.object.mode_set(mode = 'POSE')
    CC.data.layers[30] = True  
    CCpB["torso"]['head_follow']=1
    CCpB["torso"]['neck_follow']=1
    CCpB["MCH-ROT-head"].constraints[0].mute = True 
    CCpB["MCH-ROT-neck"].constraints[0].mute = True 
    CCpB["MCH-torso.parent"].lock_location=[False,False,False]
    CCpB["MCH-shin_ik.L"].constraints["IK"].iterations = 40
    CCpB["MCH-shin_ik.R"].constraints["IK"].iterations = 40
    CCpB["MCH-forearm_ik.L"].constraints["IK"].iterations = 40
    CCpB["MCH-forearm_ik.R"].constraints["IK"].iterations = 40
    CCpB["thigh_parent.L"]['IK_Stretch']=0
    CCpB["thigh_parent.R"]['IK_Stretch']=0
    if bpy.app.version >= (3, 2, 0):
        CCpB["MCH-toe_ik_parent.L"].constraints[0].mute = True
        CCpB["MCH-toe_ik_parent.R"].constraints[0].mute = True
    else :
        CCpB["MCH-toe.L"].constraints[0].mute = True
        CCpB["MCH-toe.R"].constraints[0].mute = True
    objbone =  CCpB["MCH-thigh_ik_target.L"].constraints 
    if "IK" in objbone.keys():
        objbone.remove(objbone["IK"])
    objbone.new(type="IK")
    objbone["IK"].iterations = 40
    objbone["IK"].chain_count = 1
    objbone["IK"].target = CC
    objbone["IK"].subtarget = "foot_spin_ik.L"
    objbone["IK"].use_stretch = False
    objbone =  CCpB["MCH-thigh_ik_target.R"].constraints
    if "IK" in objbone.keys():
        objbone.remove(objbone["IK"])
    objbone.new(type="IK")
    objbone["IK"].iterations = 40
    objbone["IK"].chain_count = 1
    objbone["IK"].target = CC
    objbone["IK"].subtarget = "foot_spin_ik.R"
    objbone["IK"].use_stretch = False
    if bpy.app.version >= (3, 2, 0):
        objbone =  CCpB["MCH-toe_ik_parent.L"].constraints
    else:
        objbone =  CCpB["MCH-toe.L"].constraints
    if "IK" in objbone.keys():
        objbone.remove(objbone["IK"])
    objbone.new(type="IK")
    objbone["IK"].iterations = 40
    objbone["IK"].chain_count = 1
    objbone["IK"].target = CC
    objbone["IK"].subtarget = "foot_spin_ik.L"
    objbone["IK"].use_stretch = False
    objbone["IK"].use_tail = False
    fcu = objbone["IK"].driver_add("influence")
    drv = fcu.driver
    drv.type = 'SCRIPTED'
    drv.expression = '1-var'
    var = drv.variables.new()
    var.name = 'var'
    var.targets[0].id = CC
    var.targets[0].data_path = 'pose.bones["thigh_parent.L"]["IK_FK"]'
    if bpy.app.version >= (3, 2, 0):
        objbone =  CCpB["MCH-toe_ik_parent.R"].constraints
    else:
        objbone =  CCpB["MCH-toe.R"].constraints
    if "IK" in objbone.keys():
        objbone.remove(objbone["IK"])
    objbone.new(type="IK")
    objbone["IK"].iterations = 40
    objbone["IK"].chain_count = 1
    objbone["IK"].target = CC
    objbone["IK"].subtarget = "foot_spin_ik.R"
    objbone["IK"].use_stretch = False
    objbone["IK"].use_tail = False
    fcu = objbone["IK"].driver_add("influence")
    drv = fcu.driver
    drv.type = 'SCRIPTED'
    drv.expression = '1-var'
    var = drv.variables.new()
    var.name = 'var'
    var.targets[0].id = CC
    var.targets[0].data_path = 'pose.bones["thigh_parent.R"]["IK_FK"]'
    bpy.ops.object.mode_set(mode = 'EDIT') 
    Arm_rigEb  =bpy.data.armatures[Arm_name].edit_bones
    Arm_rigEb['MCH-heel.02_rock2.R'].parent=Arm_rigEb['foot_ik.R']
    Arm_rigEb['MCH-heel.02_rock2.L'].parent=Arm_rigEb['foot_ik.L']
    Arm_rigEb['foot_heel_ik.R'].parent=None
    Arm_rigEb['foot_heel_ik.L'].parent=None
    A_length=Arm_rigEb['MCH-heel.02_roll1.L'].length
    Arm_rigEb['MCH-heel.02_roll1.L'].head=Arm_rigEb['MCH-foot_ik.parent.L'].head
    Arm_rigEb['MCH-heel.02_roll1.L'].tail=Arm_rigEb['MCH-foot_ik.parent.L'].tail
    Arm_rigEb['MCH-heel.02_roll1.L'].length=A_length
    A_length=Arm_rigEb['MCH-heel.02_roll1.R'].length
    Arm_rigEb['MCH-heel.02_roll1.R'].head=Arm_rigEb['MCH-foot_ik.parent.R'].head
    Arm_rigEb['MCH-heel.02_roll1.R'].tail=Arm_rigEb['MCH-foot_ik.parent.R'].tail
    Arm_rigEb['MCH-heel.02_roll1.R'].length=A_length
    if not 'ArmTwist_L' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="ArmTwist_L")
    Arm_rigEb['ArmTwist_L'].head=Arm_rigEb['upper_arm_fk.L'].head
    Arm_rigEb['ArmTwist_L'].tail=Arm_rigEb['upper_arm_fk.L'].tail
    Arm_rigEb['ArmTwist_L'].parent=Arm_rigEb['upper_arm_fk.L']
    if not 'ArmTwist_R' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="ArmTwist_R")
    Arm_rigEb['ArmTwist_R'].head=Arm_rigEb['upper_arm_fk.R'].head
    Arm_rigEb['ArmTwist_R'].tail=Arm_rigEb['upper_arm_fk.R'].tail
    Arm_rigEb['ArmTwist_R'].parent=Arm_rigEb['upper_arm_fk.R']
    if not 'HandTwist_L' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="HandTwist_L")
    Arm_rigEb['HandTwist_L'].head=Arm_rigEb['forearm_fk.L'].head
    Arm_rigEb['HandTwist_L'].tail=Arm_rigEb['forearm_fk.L'].tail
    Arm_rigEb['HandTwist_L'].parent=Arm_rigEb['forearm_fk.L']
    if not 'HandTwist_R' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="HandTwist_R")
    Arm_rigEb['HandTwist_R'].head=Arm_rigEb['forearm_fk.R'].head
    Arm_rigEb['HandTwist_R'].tail=Arm_rigEb['forearm_fk.R'].tail
    Arm_rigEb['HandTwist_R'].parent=Arm_rigEb['forearm_fk.R']
    Arm_rigEb['forearm_fk.L'].parent=Arm_rigEb['ArmTwist_L']
    Arm_rigEb['hand_fk.L'].parent=Arm_rigEb['HandTwist_L']
    Arm_rigEb['forearm_fk.R'].parent=Arm_rigEb['ArmTwist_R']
    Arm_rigEb['hand_fk.R'].parent=Arm_rigEb['HandTwist_R']
    if not 'Shoulder_L' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="Shoulder_L")
    Arm_rigEb['Shoulder_L'].head=Arm_rigEb['shoulder.L'].head
    Arm_rigEb['Shoulder_L'].tail=Arm_rigEb['shoulder.L'].tail
    Arm_rigEb['Shoulder_L'].parent=Arm_rigEb['ORG-spine.003']
    Arm_rigEb['shoulder.L'].parent=Arm_rigEb['Shoulder_L']
    
    if not 'Shoulder_R' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="Shoulder_R")
    Arm_rigEb['Shoulder_R'].head=Arm_rigEb['shoulder.R'].head
    Arm_rigEb['Shoulder_R'].tail=Arm_rigEb['shoulder.R'].tail
    Arm_rigEb['Shoulder_R'].parent=Arm_rigEb['ORG-spine.003']
    Arm_rigEb['shoulder.R'].parent=Arm_rigEb['Shoulder_R']
    if not 'Waist' in Arm_rigEb:
        bpy.ops.armature.bone_primitive_add(name="Waist")
    Arm_rigEb['Waist'].head=Arm_rigEb['spine_fk'].head
    Arm_rigEb['Waist'].tail=Arm_rigEb['tweak_spine'].head
    Arm_rigEb['Waist'].parent=Arm_rigEb['torso']
    Arm_rigEb['spine_fk.002'].parent=Arm_rigEb['Waist']
    Arm_rigEb['spine_fk'].parent=Arm_rigEb['Waist']
    Arm_rigEb['spine_fk.001'].parent=Arm_rigEb['MCH-spine.003']
    bpy.ops.object.mode_set(mode = 'POSE')
    bpy.ops.pose.select_all(action='DESELECT')
    Arm_rigB  =bpy.data.armatures[Arm_name].bones
    Arm_rigB['ArmTwist_L'].select=True
    Arm_rigB['ArmTwist_R'].select=True
    Arm_rigB['HandTwist_L'].select=True
    Arm_rigB['HandTwist_R'].select=True
    bpy.ops.pose.group_assign(type=1)
    bpy.ops.pose.select_all(action='DESELECT')
    Arm_rigB['Waist'].select=True
    bpy.ops.pose.group_assign(type=4)
    bpy.ops.pose.select_all(action='DESELECT')
    Arm_rigB['Shoulder_L'].select=True
    Arm_rigB['Shoulder_R'].select=True
    bpy.ops.pose.group_assign(type=3)
    CCpB["ArmTwist_L"].lock_rotation=[True,False,True]
    CCpB["ArmTwist_R"].lock_rotation=[True,False,True]
    CCpB["HandTwist_L"].lock_rotation=[True,False,True]
    CCpB["HandTwist_R"].lock_rotation=[True,False,True]
    CCpB["ArmTwist_L"].lock_location=[True,True,True]
    CCpB["ArmTwist_R"].lock_location=[True,True,True]
    CCpB["HandTwist_L"].lock_location=[True,True,True]
    CCpB["HandTwist_R"].lock_location=[True,True,True]
    CCpB["Waist"].lock_location=[True,True,True]
    for _tuples in rig_to_vmd_tuples:
        try:
            CC.data.bones[_tuples[0]].name = _tuples[1]
        except KeyError :
            pass
    __vmdFile = vmd.File()
    __vmdFile.load(filepath=filepath)
    boneAnim = __vmdFile.boneAnimation
    is_ik=False
    for name, keyFrames in boneAnim.items():
        if name =='右足ＩＫ':    
            if  len(keyFrames)>5:
                is_ik=True
                CC.data.bones['thigh_ik.R'].name = 'Leg_R'
                CC.data.bones['thigh_ik.L'].name = 'Leg_L'
            else:
                is_ik=False
                CC.data.bones['thigh_fk.R'].name = 'Leg_R'
                CC.data.bones['thigh_fk.L'].name = 'Leg_L'
    return is_ik


def chg_name_back(CC,is_ik):
    CCpB=CC.pose.bones
    bpy.ops.object.mode_set(mode = 'POSE')
    for _tuples in rig_to_vmd_tuples:
        try:
            CC.data.bones[_tuples[1]].name = _tuples[0]
        except KeyError :
            pass
    if is_ik:
        CC.data.bones['Leg_R'].name = 'thigh_ik.R'
        CC.data.bones['Leg_L'].name = 'thigh_ik.L'
    else:
        CC.data.bones['Leg_R'].name = 'thigh_fk.R'
        CC.data.bones['Leg_L'].name = 'thigh_fk.L'
    CCpB["MCH-thigh_ik_target.L"].constraints["IK"].chain_count = 1 
    CCpB["MCH-thigh_ik_target.R"].constraints["IK"].chain_count = 1 #
    if bpy.app.version >= (3, 2, 0):
        CCpB["MCH-toe_ik_parent.L"].constraints["IK"].chain_count = 1
        CCpB["MCH-toe_ik_parent.R"].constraints["IK"].chain_count = 1
    else:
        CCpB["MCH-toe.L"].constraints["IK"].chain_count = 1
        CCpB["MCH-toe.R"].constraints["IK"].chain_count = 1
    if is_ik:
        a2c3c0ops=0
    else:
        a2c3c0ops=1
    CCpB["upper_arm_parent.L"]["IK_FK"] = 1
    CCpB["upper_arm_parent.R"]["IK_FK"] = 1
    CCpB["thigh_parent.L"]["IK_FK"] = a2c3c0ops
    CCpB["thigh_parent.R"]["IK_FK"] = a2c3c0ops   
    for i in (1,2,30):
        bpy.context.object.data.layers[i] = False

def chg_en_to_jp(context):
    for _tuples in jp_to_rig:
            bpy.context.object.data.bones[_tuples[1]].name = _tuples[0]
def chg_jp_to_en(context):
    for _tuples in jp_to_rig:
            bpy.context.object.data.bones[_tuples[0]].name = _tuples[1]
