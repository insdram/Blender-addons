import bpy
import logging
import traceback
from mathutils import Vector
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy_extras.object_utils import AddObjectHelper, object_data_add

from mmd_tools_change import register_wrap
from mmd_tools_change.chg_name import chg_name,chg_name_back
from mmd_tools_change.translations import DictionaryEnum
import mmd_tools_change.core.vmd.importer as vmd_importer
import mmd_tools_change.core.vmd.exporter as vmd_exporter
from mmd_tools_change.core.camera import MMDCamera

@register_wrap
class SimpleChain(Operator,AddObjectHelper):
    """简单的布料骨骼"""
    bl_idname = "mmd_to_rigfy.simple_chain"
    bl_label = "create simple chain"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj.type == 'ARMATURE'

    def execute(self, context):
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        window = bpy.context.window_manager.windows[0]
        screen = window.screen
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                override = {'window': window, 'screen': screen, 'area': area}
                break
        obj = context.active_object
        if obj.type == 'ARMATURE':
            bpy.ops.object.mode_set(mode = 'POSE')
            selected_bones = []
            if bpy.context.selected_pose_bones[0].parent==None:
                pose_pa = False
            else :
                pose_pa = True
                select_p_name = bpy.context.selected_pose_bones[0].parent.name
            if bpy.context.selected_pose_bones ==[]:
                bpy.ops.pose.select_all(action='SELECT')
            for s_bones in bpy.context.selected_pose_bones:
                selected_bones = selected_bones + [s_bones.name]
            bpy.ops.object.mode_set(mode = 'OBJECT')
            verts = []
            edges = []
            faces = []
            edge_i = 0
            for _name in selected_bones:
                vec = obj.data.bones[_name].head_local
                verts = verts+[vec]
                edge_i += 1
                edges = edges+[(edge_i-1,edge_i)]
            verts = verts+[obj.data.bones[-1].tail_local]
            ana_name=obj.name + selected_bones[0] + '_analog'
            if ana_name in bpy.data.objects.keys():
                bpy.ops.object.select_all(action = 'DESELECT')
                bpy.data.objects[ana_name].select_set(True)
                bpy.ops.object.delete()

            mesh = bpy.data.meshes.new(ana_name)
            mesh.from_pydata(verts,edges,faces)
            object_data_add(context, mesh,name=ana_name)
            obj_mesh = context.active_object

            bpy.data.objects[obj_mesh.name].constraints.new(type='COPY_LOCATION')
            bpy.data.objects[obj_mesh.name].constraints[0].use_offset = True
            if pose_pa:
                bpy.data.objects[obj_mesh.name].constraints[0].target = obj
                bpy.data.objects[obj_mesh.name].constraints[0].subtarget = select_p_name
            bpy.ops.object.mode_set(mode = 'EDIT') 
            bpy.ops.mesh.select_mode(type="VERT")
            bpy.ops.mesh.select_all(action = 'DESELECT')
            for i in range(edge_i+1):
                bpy.ops.object.mode_set(mode = 'OBJECT')
                bpy.data.meshes[mesh.name].vertices[i].select = True 
                bpy.ops.object.mode_set(mode = 'EDIT')
                bpy.ops.object.vertex_group_assign_new(override) 
                bpy.ops.mesh.select_all(action = 'DESELECT')
            bpy.data.objects[obj_mesh.name].modifiers.new(name='模拟',type='CLOTH')
            vert_g_name = obj_mesh.vertex_groups.keys() 
            obj_mesh.modifiers[0].settings.vertex_group_mass = vert_g_name[0] 
            obj_mesh.modifiers[0].settings.bending_model = 'LINEAR'
            obj_mesh.modifiers[0].settings.time_scale = 2
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.extrude_region_move(MESH_OT_extrude_region={"use_normal_flip":False, "use_dissolve_ortho_edges":False, "mirror":False}, TRANSFORM_OT_translate={"value":(-0.01, -0, -0), "orient_axis_ortho":'X', "orient_type":'GLOBAL', "orient_matrix":((1, 0, 0), (0, 1, 0), (0, 0, 1)), "orient_matrix_type":'GLOBAL', "constraint_axis":(True, False, False), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "view2d_edge_pan":False, "release_confirm":False, "use_accurate":False, "use_automerge_and_split":False})
            context.view_layer.objects.active = obj 
            bpy.ops.object.mode_set(mode = 'POSE')
            
            armature_name = obj.name
            ana_name = obj_mesh.name
            i = 0
            for _name in selected_bones:           
                objbone =  bpy.data.objects[armature_name].pose.bones[_name].constraints
                for cons in objbone.values():
                    objbone.remove(cons)
                objbone.new(type='COPY_LOCATION')
                objbone[0].target = bpy.data.objects[ana_name]
                objbone[0].subtarget = vert_g_name[i]
                objbone.new(type='DAMPED_TRACK')
                objbone[1].target = bpy.data.objects[ana_name]
                objbone[1].subtarget = vert_g_name[i+1]
                i +=1
            bpy.ops.object.mode_set(mode = 'OBJECT')
        else:
            print("invalid object")    
        return {'FINISHED'}
            


@register_wrap
class ImportVmd(Operator, ImportHelper):
    """导入Vmd文件，日文或英文"""
    bl_idname = 'mmd_to_rigfy.import_vmd'
    bl_label = 'Import VMD File (.vmd)'
    bl_description = 'Import a VMD file to selected objects (.vmd)'
    bl_options = {'REGISTER', 'UNDO', 'PRESET'}

    filename_ext = '.vmd'
    filter_glob = bpy.props.StringProperty(default='*.vmd', options={'HIDDEN'})
    margin = bpy.props.IntProperty(
        name='Margin',
        description='How many frames added before motion starting',
        min=0,
        default=1,
        )
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        is_ok=False
        if obj.type == 'ARMATURE':
            for _root in bpy.data.armatures[obj.name].bones.keys():
                if 'root' in _root:
                    is_ok=True
        elif obj.type =='CAMERA':
                is_ok=True
        return is_ok


    def execute(self, context):
        if  context.object.type=='ARMATURE':
            Arm_name = bpy.context.object.name
            gs=0.1*bpy.data.armatures[Arm_name].bones['root'].length
            CC = bpy.context.object
            is_ik = chg_name(CC,filepath=self.filepath)
        else :
            gs=0.1
        bone_mapper = None
        bone_mapper = vmd_importer.RenamedBoneMapper(
            rename_LR_bones=True,
            use_underscore=True,
            translator=DictionaryEnum.get_translator('INTERNAL'),#DISABLED INTERNAL
            ).init
        importer = vmd_importer.VMDImporter(
            filepath=self.filepath,
            scale=gs,
            bone_mapper=bone_mapper,
            frame_margin=self.margin
            )
        selected_objects = set(context.selected_objects)
        for i in selected_objects:
            importer.assign(i)
        if  context.object.type=='ARMATURE':
            CC = bpy.context.object
            chg_name_back(CC,is_ik=is_ik)
        setupFrameRanges()
        setupFps()
        context.scene.frame_set(context.scene.frame_current)

        return {'FINISHED'}



@register_wrap
class ExportVmd(Operator, ExportHelper):
    """导出Vmd文件，英文"""
    bl_idname = 'mmd_to_rigfy.export_vmd'
    bl_label = 'Export VMD File (.vmd)'
    bl_description = 'Export motion data of active object to a VMD file (.vmd)'
    bl_options = {'PRESET'}

    filename_ext = '.vmd'
    filter_glob = bpy.props.StringProperty(default='*.vmd', options={'HIDDEN'})

    scale = bpy.props.FloatProperty(
        name='Scale',
        description='Scaling factor for exporting the motion',
        default=10,
        )
    use_pose_mode = bpy.props.BoolProperty(
        name='设置当前姿势为默认',
        description='You can pose the model to export a motion data to different pose base, such as T-Pose or A-Pose',
        default=False,
        options={'SKIP_SAVE'},
        )
    use_frame_range = bpy.props.BoolProperty(
        name='限定帧数',
        description = 'Export frames only in the frame range of context scene',
        default = False,
        )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj.type in ['ARMATURE', 'CAMERA']

    def execute(self, context):
        params = {
            'filepath':self.filepath,
            'scale':self.scale,
            'use_pose_mode':self.use_pose_mode,
            'use_frame_range':self.use_frame_range,
            }

        obj = context.active_object
        print(obj.type)
        if obj.type == 'ARMATURE':
            params['armature'] = obj
            params['model_name'] = obj.name
            chg_name(context)#rig->en
        else:
            for i in context.selected_objects:
                if MMDCamera.isMMDCamera(i):
                    params['camera'] = i

        try:
            vmd_exporter.VMDExporter().export(**params)
        except Exception as e:
            err_msg = traceback.format_exc()
            logging.error(err_msg)
            self.report({'ERROR'}, err_msg)

        return {'FINISHED'}

def setupFrameRanges():
    s, e = 1, 1
    for i in bpy.data.actions:
        ts, te = i.frame_range
        s = int(min(s, ts))
        e = int(max(e, te))
    bpy.context.scene.frame_start = s
    bpy.context.scene.frame_end = e
    if bpy.context.scene.rigidbody_world is not None:
        bpy.context.scene.rigidbody_world.point_cache.frame_start = s
        bpy.context.scene.rigidbody_world.point_cache.frame_end = e



def setupFps():
    bpy.context.scene.render.fps = 30
    bpy.context.scene.render.fps_base = 1


