# -*- coding: UTF-8 -*-
from .iBlender_ARP import _

import bpy

def update_all_tab_names(self, context):
    try:
        from . import auto_rig, auto_rig_ge, auto_rig_smart, auto_rig_remap, rig_functions
        auto_rig.update_arp_tab()
        auto_rig_ge.update_arp_tab()
        auto_rig_smart.update_arp_tab()
        auto_rig_remap.update_arp_tab()
        rig_functions.update_arp_tab()
    except:
        pass
        

class ARP_MT_arp_addon_preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    def update_language(self, context):
        bpy.context.preferences.view.language = self.language
        if bpy.context.preferences.view.language != "en_US":
            bpy.context.preferences.view.use_translate_new_dataname = False
        bpy.ops.script.reload()

    language: bpy.props.EnumProperty(
        name=_("Language"),
        description=_("Language Description"),
        default= bpy.context.preferences.view.language if bpy.context.preferences.view.language in ["zh_CN", "zh_TW"] else "en_US",
        update=update_language,
        items=[
            ("en_US", "English", "English"),
            # ("es", "Español", "Spanish"),
            # ("it_IT", "Italiano", "Italian"),
            # ("ja_JP", "日本語", "Japanese"),
            ("zh_CN", "简体中文", "Simplified Chinese"),
            ("zh_TW", "繁體中文", "Traditional Chinese"),
            # ("ru_RU", "русский", "Russian"),
            # ("fr_FR", "Français", "French"),
            # ("de_DE", "Deutsch", "German"),
            # ("ko_KR", "한국어(한국)", "Korean")
            # ('pt_PT', 'Português', 'Portuguese'),
            # ('nl_NL', 'Nederlands', 'Dutch'),
        ],
    )

    arp_tab_name : bpy.props.StringProperty(name=_('Interface Tab'), description='Interface Tab\nName of the tab to display the interface in', default='ARP', update=update_all_tab_names)
    arp_tools_tab_name : bpy.props.StringProperty(name=_('Tools Interface Tab'), description='Tools Interface Tab\nName of the tab to display the tools (IK-FK snap...) interface in', default='Tool', update=update_all_tab_names)
    custom_limb_path: bpy.props.StringProperty(name=_('Custom Limbs Path'), subtype='FILE_PATH', default='/Custom Limbs/', description='Custom Limbs Path\nPath to store custom limb presets')
    rig_layers_path: bpy.props.StringProperty(name=_('Rig Layers Path'), subtype='FILE_PATH', default='/Rig Layers/', description='Rig Layers Path\nPath to store rig layers presets')
    remap_presets_path: bpy.props.StringProperty(name=_('Remap Presets Path'), subtype='FILE_PATH', default='/Remap Presets/', description='Remap Presets Path\nPath to store remap presets')
    default_ikfk_arm: bpy.props.EnumProperty(items=(('IK', 'IK', 'IK'), ('FK', 'FK', 'FK')), description='Default value for arms IK-FK switch', name=_('IK-FK Arms Default'))
    default_ikfk_leg: bpy.props.EnumProperty(items=(('IK', 'IK', 'IK'), ('FK', 'FK', 'FK')), description='Default value for legs IK-FK switch', name=_('IK-FK Legs Default'))
    default_head_lock: bpy.props.BoolProperty(default=True, name=_('Head Lock Default'), description='Head Lock Default\nDefault value for the Head Lock switch')
    remove_existing_arm_mods: bpy.props.BoolProperty(default=True, name=_('Remove Armature Modifiers'), description='Remove Armature Modifiers\nRemove existing armature modifiers when binding')
    rem_arm_mods_set: bpy.props.BoolProperty(default=False, description='Toggle to be executed the first time binding, to set default prefs')
    
    def draw(self, context):
        layout = self.layout
        box = layout.box()       

        box.prop(self, "language")

        box.label(text=_("Translation is in progress. Whole text isn't translated"))

        row = self.layout.row()
        row.operator("wm.url_open", text=_("Watch online video tutorials")).url = "https://www.bilibili.com/video/BV1Hy4y117V7/"
        row.operator("wm.url_open", text=_("Chat Room")).url = "https://jq.qq.com/?_wv=1027&k=hqUuPdW7"
        row.operator("wm.url_open", text=_("Buy More")).url = "https://i123.taobao.com/"
      


        col = self.layout.column(align=True)
        col.label(text=_('Default:'))
        col.prop(self, 'remove_existing_arm_mods', text=_('Remove Existing Armature Modifiers when Binding'))
        col.prop(self, 'default_ikfk_arm', text=_('IK-FK Arms'))
        col.prop(self, 'default_ikfk_leg', text=_('IK-FK Legs'))
        col.prop(self, 'default_head_lock', text=_('Head Lock'))
        
        col.separator()
        col.label(text=_('Interface:'))
        col.prop(self, 'arp_tab_name', text=_('Main ARP Tab'))
        col.prop(self, 'arp_tools_tab_name', text=_('Tools Tab')) 

        col.separator()
        col.label(text=_('Paths:'))
        col.prop(self, 'custom_limb_path')
        col.prop(self, 'rig_layers_path')
        col.prop(self, 'remap_presets_path')
        
        col.separator()
        col.label(text=_('Special:'))
        col.prop(context.scene, 'arp_debug_mode')
        col.prop(context.scene, 'arp_experimental_mode')
        
        
        

def register():
    from bpy.utils import register_class

    try:
        register_class(ARP_MT_arp_addon_preferences)
    except:
        pass
    bpy.types.Scene.arp_debug_mode = bpy.props.BoolProperty(name=_('Debug Mode'), default = False, description = 'Debug Mode\nRun the addon in debug mode (should be enabled only for debugging purposes, not recommended for a normal usage)')
    bpy.types.Scene.arp_experimental_mode = bpy.props.BoolProperty(name=_('Experimental Mode'), default = False, description = 'Experimental Mode\nEnable experimental, unstable tools. Warning, can lead to errors. Use it at your own risks.')

def unregister():
    from bpy.utils import unregister_class
    unregister_class(ARP_MT_arp_addon_preferences)

    del bpy.types.Scene.arp_debug_mode
    del bpy.types.Scene.arp_experimental_mode
