
__bl_classes = []
def register_wrap(cls):
    bl_props = {k:v for k, v in cls.__dict__.items() if isinstance(v, __bpy_property)}
    if bl_props:
        if '__annotations__' not in cls.__dict__:
            setattr(cls, '__annotations__', {})
        annotations = cls.__dict__['__annotations__']
        for k, v in bl_props.items():
            annotations[k] = v
            delattr(cls, k)
    if hasattr(cls, 'bl_rna'):
        __bl_classes.append(cls)
    return cls


if "bpy" in locals():
    import importlib
    importlib.reload(rig_properties)
    importlib.reload(rig_fileio)
else:
    import bpy
    __bpy_property = (bpy.props._PropertyDeferred if hasattr(bpy.props, '_PropertyDeferred') else tuple)
    from . import rig_properties
    from . import rig_fileio
    


def register():
    for cls in __bl_classes:
        bpy.utils.register_class(cls)
    rig_properties.register()

def unregister():
    rig_properties.unregister()
    for cls in reversed(__bl_classes):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass


