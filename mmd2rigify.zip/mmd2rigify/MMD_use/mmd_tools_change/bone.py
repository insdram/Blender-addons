# -*- coding: utf-8 -*-
from bpy.props import BoolProperty
from mmd_tools_change import register_wrap


def _mmd_ik_toggle_get(prop):
    return prop.get('mmd_ik_toggle', True)

def _mmd_ik_toggle_set(prop, v):
    if v != prop.get('mmd_ik_toggle', None):
        prop['mmd_ik_toggle'] = v
        _mmd_ik_toggle_update(prop, None)

def _mmd_ik_toggle_update(prop, context):
    v = prop.mmd_ik_toggle
    for b in prop.id_data.pose.bones:
        for c in b.constraints:
            if c.type == 'IK' and c.subtarget == prop.name:
                c.influence = v
                b = b if c.use_tail else b.parent
                for b in ([b]+b.parent_recursive)[:c.chain_count]:
                    c = next((c for c in b.constraints if c.type == 'LIMIT_ROTATION' and not c.mute), None)
                    if c: c.influence = v

class _MMDPoseBoneProp:
    mmd_ik_toggle = BoolProperty(
        name='MMD IK Toggle',
        description='MMD IK toggle is used to import/export animation of IK on-off',
        update=_mmd_ik_toggle_update,
        default=True,
        )

